/*
Configuration here!
  // D0 NOT REMOVE THIS LINE //
*/

var Clock = "12h";	       // choose between "12h" or "24h".
var lang = "en";		   // choose between "sp", "en", "de" or "fr".


var Code = Dacal;
var Modified = Orsxn
// Code by Dacal -- Modified by OrsonCopeland